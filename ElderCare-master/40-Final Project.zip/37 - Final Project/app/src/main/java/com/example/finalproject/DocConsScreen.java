package com.example.finalproject;

import static com.example.finalproject.Patho.finaluser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DocConsScreen extends AppCompatActivity {
    private DatabaseReference mDatabase;
    String requestEditText;
    private FirebaseAuth firebaseAuth;
    public static String resultemail;
    public static String finaluser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_cons_screen);
        firebaseAuth = FirebaseAuth.getInstance();
        final FirebaseUser users = firebaseAuth.getCurrentUser();
        finaluser = users.getEmail();
        resultemail = finaluser.replace(".", "");
        // Get a reference to the Firebase Realtime Database
        mDatabase = FirebaseDatabase.getInstance().getReference("ElderCare Application");

        // Get the request EditText
        requestEditText = "Request for a doctor ";

        // Set the click listener for the send button
        Button sendButton = findViewById(R.id.send_button);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the current user ID
                String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                // Create a new UserRequest object with the user ID and request message
//                UserRequest request = new UserRequest(userId, requestEditText);
                String des = resultemail+" is requesting for a Doctor!";
                Request request = new Request(userId,"Pending", des , requestEditText);
                // Save the request to the Firebase Realtime Database
                mDatabase.child("Admin").child("Requests").child(resultemail).setValue(request);
                // Clear the EditText
                requestEditText="";
                // Show a message to the user that the request has been sent
                Toast.makeText(DocConsScreen.this, "Request sent", Toast.LENGTH_SHORT).show();
            }
        });
    }
}