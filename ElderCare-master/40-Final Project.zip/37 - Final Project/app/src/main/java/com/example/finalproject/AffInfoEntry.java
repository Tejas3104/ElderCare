package com.example.finalproject;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.core.view.View;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
public class AffInfoEntry extends AppCompatActivity {
    Calendar myCalender;
    ImageView UploadPhoto;
    EditText etDate,NameText;
    RadioButton male, female, other;
    Uri uri;
    Button SubmitButton;
    public static String affname,affDOB,affimageURL,affgender;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aff_info_entry);

        NameText = findViewById(R.id.name);
        etDate = findViewById(R.id.DOB);
        female = findViewById(R.id.rb1);
        male = findViewById(R.id.rb2);
        other = findViewById(R.id.rb3);
        SubmitButton = findViewById(R.id.next);
        UploadPhoto = findViewById(R.id.UpPhoto);
        myCalender = Calendar.getInstance();
        String gmale="Male";
        String gfemale="Female";
        String gother="Other";

        databaseReference = FirebaseDatabase.getInstance().getReference("ElderCare Android Application");

        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    //                    @Override
//                    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//                        onActivityResult(requestCode, resultCode, data);
//                        if(requestCode == 2 && resultCode == RESULT_OK && data != null){
//                            uri = data.getData();
//                            UploadPhoto.setImageURI(uri);
//                        }
//                    }
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == Activity.RESULT_OK){
                            Intent data = result.getData();
                            uri = data.getData();
                            UploadPhoto.setImageURI(uri);
                        } else {
                            Toast.makeText(AffInfoEntry.this, "No Image Selected!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        UploadPhoto.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                Intent photoPicker = new Intent();
                photoPicker.setAction(Intent.ACTION_GET_CONTENT);
                photoPicker.setType("image/*");
//                activityResultLauncher.launch(photoPicker);
                startActivityForResult(photoPicker, 2);
            }
        });

        SubmitButton.setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(android.view.View v) {
                        if(female.isChecked()){
                            affgender=gfemale;
                        }else if(male.isChecked()){
                            affgender=gmale;
                        }else{
                            affgender=gother;
                        }
//                        UploadToFirebase(uri);
                        uploadData();
                    }
                }
        );

        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                myCalender.set(Calendar.YEAR, year);
                myCalender.set(Calendar.MONTH, month);
                myCalender.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };
        etDate.setOnClickListener(view -> {
            new DatePickerDialog(AffInfoEntry.this, date, myCalender.get(Calendar.YEAR), myCalender.get(Calendar.MONTH), myCalender.get(Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void uploadData() {
        affname = NameText.getText().toString();
        affDOB = etDate.getText().toString();
        affimageURL = "Image URL";
        AffDataClass affDataClass=new AffDataClass(affname,affDOB,affimageURL,affgender);
        String currentDate = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
        Toast.makeText(AffInfoEntry.this, "Saved", Toast.LENGTH_SHORT).show();
        Intent intent2= new Intent(AffInfoEntry.this, AffMySignup.class);
        startActivity(intent2);
        finish();
    }
    private void updateLabel() {
        String myFormat = "dd/MM/yy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        etDate.setText(dateFormat.format(myCalender.getTime()));
    }
}