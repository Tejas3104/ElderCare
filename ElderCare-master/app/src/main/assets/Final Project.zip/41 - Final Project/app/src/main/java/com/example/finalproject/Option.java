package com.example.finalproject;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Option extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    public static String resultemail;
    public DatabaseReference databaseReference;
    public FirebaseDatabase usersRef;
    Button user, aff, admin;

    private static final String AFFILIATE_PATH = "/ElderCare Application/Affiliate/Doctor";
    private static final String ADMIN_PATH = "/ElderCare Application/Admin";
    private static final String USERS_PATH = "/ElderCare Application/Users";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);
        firebaseAuth = FirebaseAuth.getInstance();

        user = findViewById(R.id.userbutt);
        aff = findViewById(R.id.affbutt);
        admin = findViewById(R.id.adminbutt);
        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Option.this, LogReg.class);
                startActivity(intent);
            }
        });
        aff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Option.this, AffSendOTP.class);
                startActivity(intent);
            }
        });
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Option.this, AdminLogin.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        if (firebaseAuth.getCurrentUser() != null) {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            FirebaseUser currentUser = mAuth.getCurrentUser();
            String userEmail = currentUser.getEmail();
            resultemail = userEmail.replace(".", "");
            usersRef = FirebaseDatabase.getInstance();

            if (currentUser.getEmail().equals("admin@eldercare.com")) {
                Toast.makeText(Option.this, "Admin already logged-in!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Option.this, AdminHome.class));
                finish();
            } else {
                checkAffiliateLogin();
            }
        } else {
            Toast.makeText(Option.this, "Welcome !", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkAffiliateLogin() {
        databaseReference = usersRef.getReference(AFFILIATE_PATH).child(resultemail);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // If the dataSnapshot is null, the user is not an affiliate
                if (dataSnapshot != null && dataSnapshot.exists()) {
                    // User is an affiliate
                    Toast.makeText(Option.this, "Affiliate already logged-in!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Option.this, AffHome.class));
                    finish();
                }
                else {
                    Toast.makeText(Option.this, "Already logged-in!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Option.this, NavigationDrawer.class));
                    finish();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        };
        databaseReference.addListenerForSingleValueEvent(eventListener);
    }
}