package com.example.finalproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DocConsScreen extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private FirebaseAuth firebaseAuth;
    private String resultemail;
    private List<Doctor> doctors;
    private RecyclerView recyclerView;
    private DoctorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_cons_screen);

        // Initialize Firebase Authentication
        firebaseAuth = FirebaseAuth.getInstance();

        // Get the current user's email
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            resultemail = user.getEmail().replace(".", "");
        }

        // Get a reference to the Firebase Realtime Database
        mDatabase = FirebaseDatabase.getInstance().getReference("ElderCare Application");

        // Initialize the doctors list and RecyclerView
        doctors = new ArrayList<>();
        recyclerView = findViewById(R.id.doctor_list);

        if (recyclerView != null) {
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new DoctorAdapter(doctors);
            recyclerView.setAdapter(adapter);
        }
        // Set the click listener for the send button
        Button sendButton = findViewById(R.id.send_button);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference requestsRef = mDatabase.child("Admin").child("Requests").child(resultemail);
                requestsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            Request request = snapshot.getValue(Request.class);
                            String status = request.getStatus();
                            switch (status) {
                                case "Pending":
                                    TextView msg = findViewById(R.id.reqmsg);
                                    msg.setText(R.string.pending_msg);
                                    msg.setTextSize(25);
                                    sendButton.setVisibility(View.INVISIBLE);
                                    break;
                                case "Approved":
                                    DatabaseReference doctorsRef = mDatabase.child("Affiliate").child("Doctor");
                                    doctorsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            doctors.clear();
                                            for (DataSnapshot doctorSnapshot : snapshot.getChildren()) {
                                                Doctor doctor = doctorSnapshot.getValue(Doctor.class);
                                                // Add only professional details to the doctors list
                                                Doctor professionalDetailsOnly = new Doctor();
                                                professionalDetailsOnly.setProfessionalDetails(doctor.getProfessionalDetails());
                                                doctors.add(professionalDetailsOnly);
                                            }
                                            if (recyclerView != null) {
                                                if (adapter == null) {
                                                    adapter = new DoctorAdapter(doctors);
                                                    recyclerView.setAdapter(adapter);
                                                } else {
                                                    adapter.notifyDataSetChanged();
                                                }
                                            }
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            // TODO: Handle the error
                                        }
                                    });

                                    break;
                                case "Denied":
                                    TextView msg2 = findViewById(R.id.reqmsg);
                                    msg2.setText(R.string.denied_msg);
                                    msg2.setTextSize(25);
                                    break;
                            }
                        } else {
                            String des = resultemail + " is requesting for a Doctor!";
                            Request request = new Request(firebaseAuth.getCurrentUser().getUid(), "Request for a doctor", des, "Pending");
                            mDatabase.child("Admin").child("Requests").child(resultemail).setValue(request);
                            Toast.makeText(DocConsScreen.this, "Request sent !", Toast.LENGTH_SHORT).show();
                            TextView msg = findViewById(R.id.reqmsg);
                            msg.setText(R.string.sent);
                            msg.setTextSize(25);
                            sendButton.setVisibility(View.INVISIBLE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // TODO: Handle the error
                    }
                });
            }
        });
    }
}
