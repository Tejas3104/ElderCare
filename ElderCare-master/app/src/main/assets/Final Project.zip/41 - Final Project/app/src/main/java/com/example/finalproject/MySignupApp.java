package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;

public class MySignupApp extends AppCompatActivity {
    EditText inputEmail,inputPassword,inputConfirmPassword;
    Button btnRegister;
    String emailPattern= "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
   ProgressDialog progressDialog;
   FirebaseAuth mAuth;
   FirebaseUser mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_my_signup_app);

        inputEmail=findViewById(R.id.email);
        inputPassword=findViewById(R.id.password);
        inputConfirmPassword=findViewById(R.id.repassword);
        btnRegister=findViewById(R.id.signupbtn);
        progressDialog=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null && user.isEmailVerified()) {
                    // Launch Medical activity
                    Intent intent = new Intent(MySignupApp.this, Medical.class);
                    startActivity(intent);
                }
            }
        });

        mUser=mAuth.getCurrentUser();

        MaterialButton regbtn = (MaterialButton) findViewById(R.id.signupbtn);

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
//                String username1 = username.getText().toString();
//                Toast.makeText(MySignupApp.this, "Username is"+username1, Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PerformAuth();
            }
        });
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if(requestCode == 1000){
//            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
//            try {
//                task.getResult(ApiException.class);
//                navigateToSecondActivity();
//            } catch (ApiException e) {
////                throw new RuntimeException(e);
//                Toast.makeText(getApplicationContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//    public void navigateToSecondActivity() {
//        finish();
//        Intent intent = new Intent(MySignupApp.this, Medical.class);
//        startActivity(intent);
//    }

    private void PerformAuth() {
        String email=inputEmail.getText().toString();
        String password=inputPassword.getText().toString();
        String confirmpassword=inputConfirmPassword.getText().toString();

        if(!email.matches(emailPattern))
        {
            inputEmail.setError("Enter valid email !");
            inputEmail.requestFocus();
        }
        else if(email.isEmpty() || email.length()<10)
        {
            inputEmail.setError("Enter valid email !");
            inputEmail.requestFocus();
        }
        else if(password.isEmpty()  || password.length()<8)
        {
            inputPassword.setText("Password should to more than or equal to 8 characters !");
            inputPassword.requestFocus();
        }else if(confirmpassword.isEmpty()  || confirmpassword.length()<8)
        {
            inputPassword.setText("Password should to more than or equal to 8 characters !");
            inputPassword.requestFocus();
        }
        else if(!password.equals(confirmpassword))
        {
            inputPassword.setError("Passwords do not match !");
            inputPassword.requestFocus();
            inputConfirmPassword.setError("Passwords do not match !");
            inputConfirmPassword.requestFocus();
            inputConfirmPassword.setText("");
        }
        else
        {
            progressDialog.setMessage("Please wait while registration...");
            progressDialog.setTitle("Registration");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            doRegister(email,password);
        }
    }

    private void doRegister(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    FirebaseUser mUser1 = mAuth.getCurrentUser();
                    mUser1.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(MySignupApp.this,"Email has been sent to your email address !",Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(),"Oops! Failed to send verification email !",Toast.LENGTH_SHORT).show();
                        }
                    });

                    // Check if email is verified
                    if(mUser1.isEmailVerified()) {
                        // Launch Medical activity
                        Intent intent = new Intent(MySignupApp.this, Medical.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MySignupApp.this, "Please verify your email address.", Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                    Toast.makeText(MySignupApp.this, "Registration Successful !", Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if(e instanceof FirebaseAuthUserCollisionException)
                {
                    inputEmail.setError("Email already registered !");
                    inputEmail.requestFocus();
                }
                else
                {
                    Toast.makeText(MySignupApp.this,"Oops! Something went wrong.",Toast.LENGTH_SHORT).show();
                }
            }
        });
        mAuth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null && user.isEmailVerified()) {
                    // Launch Medical activity
                    Intent intent = new Intent(MySignupApp.this, Medical.class);
                    startActivity(intent);
                    mAuth.removeAuthStateListener(this); // remove listener once activity is launched
                }
            }
        });
        FirebaseUser currentUser = mAuth.getCurrentUser();

        AuthCredential credential = EmailAuthProvider.getCredential(email, password);

// Link the new account with the existing account
        currentUser.linkWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Account linking successful, launch the Medical activity
                    Intent intent = new Intent(MySignupApp.this, Medical.class);
                    startActivity(intent);
                } else {
                    // Account linking failed, handle the error
                    Toast.makeText(MySignupApp.this, "Failed to link accounts: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    //    private void doRegister(String email, String password) {
//
//        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//            @Override
//            public void onComplete(@NonNull Task<AuthResult> task) {
//                if(task.isSuccessful())
//                {
//                    FirebaseUser mUser1 = mAuth.getCurrentUser();
//                    mUser1.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
//                        @Override
//                        public void onSuccess(Void unused) {
//                            Toast.makeText(MySignupApp.this,"Email has been sent to your email address !",Toast.LENGTH_SHORT).show();
//
//                        }
//                    }).addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception e) {
//                            Toast.makeText(getApplicationContext(),"Oops! Failed to send verification email !",Toast.LENGTH_SHORT).show();
//                        }
//                    });
//                    progressDialog.dismiss();
//                   // sendVerificationEmail();
//                    //sendUserToNextActivity();
//                    Toast.makeText(MySignupApp.this, "Registration Successful !", Toast.LENGTH_SHORT).show();
//                }
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                if(e instanceof FirebaseAuthUserCollisionException)
//                {
//                    inputEmail.setError("Email already registered !");
//                    inputEmail.requestFocus();
//                }
//                else
//                {
//                    Toast.makeText(MySignupApp.this,"Oops! Something went wrong.",Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
////    private void sendVerificationEmail() {
//        if(mAuth.getCurrentUser()!=null)
//        {
//            mAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    if(task.isSuccessful())
//                    {
//                        Toast.makeText(MySignupApp.this,"Email has been sent to your email address !",Toast.LENGTH_SHORT).show();
//                    }
//                    else{
//                        Toast.makeText(getApplicationContext(),"Oops! Failed to send verification email !",Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
   //
//    private void sendUserToNextActivity() {
//        Intent intent=new Intent(MySignupApp.this,Medical.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//    }

}