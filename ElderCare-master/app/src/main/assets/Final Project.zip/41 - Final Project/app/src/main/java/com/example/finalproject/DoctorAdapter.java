package com.example.finalproject;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {
    private List<Doctor> mDoctorList;
    public DoctorAdapter(List<Doctor> doctorList) {
        mDoctorList = doctorList;
    }
    @NonNull
    @Override
    public DoctorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.doctor_item, parent, false);
        return new DoctorViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(@NonNull DoctorViewHolder holder, int position) {
        Doctor currentDoctor = mDoctorList.get(position);
        holder.mDoctorNameTextView.setText(currentDoctor.getName());
        holder.mDoctorSpecializationTextView.setText(currentDoctor.getSpecialization());
    }
    @Override
    public int getItemCount() {
        return mDoctorList.size();
    }
    public static class DoctorViewHolder extends RecyclerView.ViewHolder {
        public TextView mDoctorNameTextView;
        public TextView mDoctorSpecializationTextView;
        public DoctorViewHolder(View itemView) {
            super(itemView);
            mDoctorNameTextView = itemView.findViewById(R.id.doctor_name);
            mDoctorSpecializationTextView = itemView.findViewById(R.id.doctor_specialization);
        }
    }
}
