package com.example.finalproject;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    private FirebaseAuth firebaseAuth;
//    public static String resultemail;
//    public DatabaseReference databaseReference;
//    public static String finaluser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();
//        databaseReference = FirebaseDatabase.getInstance().getReference("ElderCare Application");
//        final FirebaseUser users = firebaseAuth.getCurrentUser();
//        if (users != null) {
//            finaluser = users.getEmail();
//            resultemail = finaluser.replace(".", "");
//
//        Query query = databaseReference.orderByChild("Users").equalTo(resultemail);
//        query.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(snapshot.exists()){
//                    Intent intent1=new Intent(MainActivity.this,NavigationDrawer.class);
//                    startActivity(intent1);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
////                throw databaseError.toException();
//            }
//        });
//
//        Query query1 = databaseReference.orderByChild("Admin").equalTo(resultemail);
//        query1.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(snapshot.exists()){
//                    Intent intent2=new Intent(MainActivity.this,AdminHome.class);
//                    startActivity(intent2);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
////                throw databaseError.toException();
//            }
//        });
//        }
//        else {
//            Intent intent3=new Intent(this,Option.class);
//            startActivity(intent3);
//        }
    }
    public void Option(View view)
    {
        Intent intent=new Intent(this,Option.class);
        startActivity(intent);
    }
    public void send_otp(View view)
    {
        Intent intent=new Intent(this,send_otp.class);
        startActivity(intent);
    }



}