package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AffLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aff_login);
    }
    public void AffReg(View view)
    {
        Intent intent=new Intent(this,AffReg.class);
        startActivity(intent);
    }
    public void AffSendOTP(View view)
    {
        Intent intent=new Intent(this,AffSendOTP.class);
        startActivity(intent);
    }
}