package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AffReg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aff_reg);
    }
    public void RegForDoc(View view)
    {
        Intent intent=new Intent(this,RegForDoc.class);
        startActivity(intent);
    }
    public void RegForCo(View view)
    {
        Intent intent=new Intent(this,RegForCo.class);
        startActivity(intent);
    }
    public void RegForPhys(View view)
    {
        Intent intent=new Intent(this,RegForPhys.class);
        startActivity(intent);
    }
    public void MedDevSupl(View view)
    {
        Intent intent=new Intent(this,MedDevSupl.class);
        startActivity(intent);
    }

}