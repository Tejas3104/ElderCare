package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.database.core.view.View;

public class AffInfoEntry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aff_info_entry);
    }
    public void AffMySignup(View view)
    {
        Intent intent=new Intent(this,AffMySignup.class);
        startActivity(intent);
    }
}